# IC Web Server
An individual project, developing a web server in C. For my University's Principles of Computer Systems and Architecture Course.

# Version History

* __Version 0.0.0 - Initial Commit__
    * Initial Commit
    
* __Version 0.1.0 - Milestone 1__
    * Attempt at Web Server
        * Implemented connection to socket
        * Implemented GET
    * No where near finish... (Sorry...)